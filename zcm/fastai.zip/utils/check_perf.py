from ..script import *
from .collect_env import *

# Temporary POC for module-based script
call_parse(check_perf)

